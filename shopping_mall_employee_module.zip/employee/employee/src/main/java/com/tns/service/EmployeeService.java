
package com.tns.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.tns.employee.entity.Employee;
import com.tns.repository.EmployeeRepository;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Integer id) {
        return employeeRepository.findById(id);
    }

    public Employee updateEmployee(Integer id, Employee updatedEmployee) {
        return employeeRepository.findById(id)
            .map(employee -> {
                employee.setName(updatedEmployee.getName());
                employee.setDob(updatedEmployee.getDob());
                employee.setSalary(updatedEmployee.getSalary());
                employee.setAddress(updatedEmployee.getAddress());
                employee.setDesignation(updatedEmployee.getDesignation());

                return employeeRepository.save(employee);
            })
            .orElse(null);
    }

    public boolean deleteEmployee(Integer id) {
        if (!employeeRepository.existsById(id)) {
            return false;
        }

        employeeRepository.deleteById(id);
        return true;
    }
}
